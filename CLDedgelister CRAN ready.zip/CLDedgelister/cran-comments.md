## R CMD check results

0 errors | 0 warnings | 0 notes

* This is a new release.

## Test environments

* local: Windows 11, R 4.4.3
* win-builder (R-devel)

## Notes on the automated check

* The CRAN incoming feasibility check flags "addin" and "mdl" as possibly
  misspelled. These are correct technical terms: "addin" refers to an RStudio
  add-in, and ".mdl" is the Vensim model file extension.
* All examples run against a small bundled model in inst/extdata, so no
  external files or internet access are required.
* The RStudio addin (cld_edgelist_addin) is interactive and uses shiny/miniUI,
  which are listed under Suggests and checked for at runtime. Its only
  assignment to the global environment is guarded by interactive() so it never
  runs during checks or batch use.
