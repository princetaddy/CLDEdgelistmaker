# CLDedgelister — RStudio plugin

Import system-dynamics / causal models and convert them to an **INPUT → OUTPUT
edge list** (cause → effect), directly inside RStudio. This is the import-and-
convert step of the SDM Network Analyzer, packaged as an R plugin so the edge
list lands straight in your R session for analysis with `igraph`, etc.

Supported formats:

| Tool | File | Notes |
|---|---|---|
| Vensim | `.mdl`, `.2mdl` | reads the diagram sketch (dotted arrows, ghost `<Var>` copies, multi-view, KEY/legend removed) |
| Stella / iThink | `.stmx`, `.itmx`, `.xmile` | XMILE standard, incl. stock–flow structure |
| Powersim Studio | `.xml` / `.xmile` | export to XMILE from Powersim first |
| AnyLogic | `.alp` | project XML: stocks, flows, variables, parameters, connectors |
| GoldSim | `.xml` | export the model to XML from GoldSim first |

## Install

From the folder containing this package:

```r
# one-time: dependencies
install.packages(c("xml2", "shiny", "miniUI", "rstudioapi", "writexl", "DT"))

# install the plugin (point at the folder, or a built .tar.gz)
install.packages("CLDedgelister", repos = NULL, type = "source")
# or, with devtools:  devtools::install("path/to/CLDedgelister")
```

Restart RStudio after installing so the addin registers.

## Use it — the point-and-click way (RStudio addin)

1. In RStudio, open the **Addins** menu (top toolbar) →
   **"Import model to edge list"**.
2. Pick the model format, choose your file.
3. The edge list previews in the window. Click **Save CSV** / **Save Excel**
   to write it out, or **Done** to send it to your workspace as the variable
   `cld_edgelist`.

## Use it — from the console

```r
library(CLDedgelister)

# see the supported formats
cld_formats()

# convert a model to a data.frame (format auto-detected from the extension)
el <- model_to_edgelist("Combined_CLD.mdl")
head(el)
#>          INPUT              OUTPUT
#> 1  Market Avail...  Manufacturing...
#> ...

# force a specific format (needed for generic .xml that could be XMILE or GoldSim)
el <- model_to_edgelist("model.xml", format = "GoldSim (exported .xml)")

# convert and write straight to disk (.csv or .xlsx)
model_to_edgelist_file("model.stmx", "model_edgelist.xlsx")

# then analyse with igraph as usual
g <- igraph::graph_from_data_frame(el, directed = TRUE)
```

The returned data.frame has two columns, `INPUT` and `OUTPUT`. When the source
model stores diagram coordinates (Vensim, Stella), they are attached as
`attr(el, "positions")` — a named list of `c(x, y)` — in case you want to draw
the original layout.

## Notes

- **Powersim and GoldSim** native files are proprietary binary formats, so the
  plugin reads their **XML / XMILE exports**. Export first, then import.
- If a model yields no edges, the most reliable fix is to export it to **XMILE**
  (`.xmile` / `.stmx`) and import that.

## Author

Taddias Prince Mpofu (princetaddy@gmail.com), with collaborative author
Joel Runyu. Open source, © 2026 — free to use, copy and redistribute.
