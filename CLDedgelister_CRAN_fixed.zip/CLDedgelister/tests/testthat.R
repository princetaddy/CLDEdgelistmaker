library(testthat)
library(CLDedgelister)

test_check("CLDedgelister")
