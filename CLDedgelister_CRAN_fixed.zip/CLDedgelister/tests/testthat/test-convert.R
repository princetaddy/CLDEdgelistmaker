test_that("cld_formats returns the five supported formats", {
  fmts <- cld_formats()
  expect_type(fmts, "character")
  expect_length(fmts, 5)
  expect_true(any(grepl("Vensim", fmts)))
  expect_true(any(grepl("GoldSim", fmts)))
})

test_that("Vensim example model converts to an edge list", {
  mdl <- system.file("extdata", "example_model.mdl", package = "CLDedgelister")
  expect_true(file.exists(mdl))
  el <- model_to_edgelist(mdl)
  expect_s3_class(el, "data.frame")
  expect_named(el, c("INPUT", "OUTPUT"))
  expect_gt(nrow(el), 0)
  # Population <-> Births/Deaths feedback should be present
  expect_true(any(el$INPUT == "Births" & el$OUTPUT == "Population"))
})

test_that("format can be auto-detected and forced", {
  mdl <- system.file("extdata", "example_model.mdl", package = "CLDedgelister")
  el1 <- model_to_edgelist(mdl)
  el2 <- model_to_edgelist(mdl, format = "Vensim (.mdl)")
  expect_equal(el1, el2)
})

test_that("writing to file works", {
  mdl <- system.file("extdata", "example_model.mdl", package = "CLDedgelister")
  out <- tempfile(fileext = ".csv")
  model_to_edgelist_file(mdl, out)
  expect_true(file.exists(out))
  back <- utils::read.csv(out, stringsAsFactors = FALSE)
  expect_named(back, c("INPUT", "OUTPUT"))
})

test_that("missing file errors cleanly", {
  expect_error(model_to_edgelist("does_not_exist.mdl"), "not found")
})
