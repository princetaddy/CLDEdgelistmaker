#' CLDedgelister: Import System-Dynamics Models and Convert Them to Edge Lists
#'
#' Imports causal / system-dynamics models from Vensim, Stella / iThink,
#' Powersim Studio, AnyLogic and GoldSim, and converts them into a two-column
#' INPUT -> OUTPUT edge list. Use \code{\link{model_to_edgelist}} from the
#' console, or the RStudio addin \code{\link{cld_edgelist_addin}}.
#'
#' @importFrom stats setNames
#' @importFrom tools file_ext file_path_sans_ext
#' @importFrom utils read.csv write.csv head
#' @keywords internal
"_PACKAGE"
