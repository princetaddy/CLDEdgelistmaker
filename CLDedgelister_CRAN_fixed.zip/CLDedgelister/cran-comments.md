## R CMD check results

0 errors | 0 warnings | 0 notes

* This is a new release.

## Test environments

* local: Windows 11, R 4.4.3
* win-builder (R-devel)

## Changes addressing the previous pre-test NOTEs

* Removed the assignment to the global environment in the RStudio add-in.
  The gadget now returns the edge list via shiny::stopApp(), so the result is
  obtained with `el <- cld_edgelist_addin()` rather than being assigned into
  the user's workspace.
* Reworded the DESCRIPTION to avoid the non-dictionary tokens previously
  flagged ("addin" -> "add-in"; the bare file-extension token was removed).

All examples run against a small bundled model in inst/extdata, so no
external files or internet access are required.
